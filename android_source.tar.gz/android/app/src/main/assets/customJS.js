/* Custom JavaScript for the application */
