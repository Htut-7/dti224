/* Android specific custom JavaScript for the application */
